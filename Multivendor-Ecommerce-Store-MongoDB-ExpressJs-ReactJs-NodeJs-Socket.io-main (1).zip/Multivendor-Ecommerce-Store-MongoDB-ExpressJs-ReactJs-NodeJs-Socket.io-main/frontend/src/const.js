export const server = "https://multivendor-ecommerce-api.onrender.com/api/v1";
export const client = "https://shopshell.netlify.app";
export const socket = "https://multivendor-ecommerce-socket.onrender.com";
